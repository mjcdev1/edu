/*
Lab 1 - PROG1960
Matt Cunningham
01/28/2026
*/

#include <iostream>
using namespace std;
#include <string>

int main()
{
    cout << "Welcome to the C++ Student Progress Tracker" << endl << endl;
    cout << "Please enter the number of students you want to track: ";

    int numStudents = 0;
    cin >> numStudents;
    cout << endl;

    string* studentFirstName = new string[numStudents];
    string* studentLastName = new string[numStudents];
    double* studentMark = new double[numStudents];

    for (int i = 0; i < numStudents; i++) {
        cout << "Entering information for student " << i + 1 << ":" << endl;
        cout << "============================================================" << endl;
        cout << "Enter Student's First Name: ";
        cin >> studentFirstName[i];
        cout << "Enter Student's Last Name: ";
        cin >> studentLastName[i];
        cout << "Enter Student's Mark (Number): ";
        cin >> studentMark[i];

        cout << endl;
    }

    for (int i = 0; i < numStudents - 1; i++) {
        for (int z = 0; z < numStudents - i - 1; z++) {
            if (studentMark[z] < studentMark[z + 1]) {
                
                string tempFirstName = studentFirstName[z];
                studentFirstName[z] = studentFirstName[z + 1];
                studentFirstName[z + 1] = tempFirstName;

                string tempLastName = studentLastName[z];
                studentLastName[z] = studentLastName[z + 1];
                studentLastName[z + 1] = tempLastName;

                double tempMark = studentMark[z];
                studentMark[z] = studentMark[z + 1];
                studentMark[z + 1] = tempMark;
            }
        }
    }

    cout << "Thank you! Here is your sorted class list (highest to lowest):" << endl;
    cout << "============================================================" << endl;

    for (int i = 0; i < numStudents; i++) {
        cout << i + 1 << ". " << studentFirstName[i] << " " << studentLastName[i] << ": " << studentMark[i] << endl;
    }

    delete[] studentFirstName;
    delete[] studentLastName;
    delete[] studentMark;

    return 0;
}

