//Matt Cunningham
//PROG1960 - Assignment #1
//2026-02-18

#include <iostream>
#include "point.h"
#include "triangle.h"

int main()
{
    cout << "Steps A and B tests:" << endl;
    cout << "==============================================================================" << endl;
    Point initPoint;
    cout << "Testing: Initialization of Point object with default values; Point class X and Y getters" << endl;
    cout << "X:" << initPoint.GetX() << endl;
    cout << "Y:" << initPoint.GetY() << endl;
    cout << endl;

    cout << "Testing: Initialization of Point object with specific values; Point class X and Y getters" << endl;
    Point testPoint1(12, 15);
    cout << "X:" << testPoint1.GetX() << endl;
    cout << "Y:" << testPoint1.GetY() << endl;
    cout << endl;

    cout << "Testing: Point class X and Y setters; Point class X and Y getters" << endl;
    testPoint1.SetX(25);
    testPoint1.SetY(30);
    cout << "X:" << testPoint1.GetX() << endl;
    cout << "Y:" << testPoint1.GetY() << endl;
    cout << endl;

    cout << "Testing: Initialization of Triangle object with default values; Triangle class A B and C getters" << endl;
    Triangle initTriangle;
    cout << "A: (" << initTriangle.GetA().GetX() << ", " << initTriangle.GetA().GetY() << ")" << endl;
    cout << "B: (" << initTriangle.GetB().GetX() << ", " << initTriangle.GetB().GetY() << ")" << endl;
    cout << "C: (" << initTriangle.GetC().GetX() << ", " << initTriangle.GetC().GetY() << ")" << endl;
    cout << endl;

    cout << "Testing: Initialization of Triangle object with specific coordinates; Triangle class A B and C getters" << endl;
    Triangle testTriangle1(1, 2, 3, 4, 5, 6);
    cout << "A: (" << testTriangle1.GetA().GetX() << ", " << testTriangle1.GetA().GetY() << ")" << endl;
    cout << "B: (" << testTriangle1.GetB().GetX() << ", " << testTriangle1.GetB().GetY() << ")" << endl;
    cout << "C: (" << testTriangle1.GetC().GetX() << ", " << testTriangle1.GetC().GetY() << ")" << endl;
    cout << endl;

    cout << "Testing: Triangle class A B and C setters (also uses Point class); Triangle class A B and C getters" << endl;
    testTriangle1.SetA(Point(0, 5));
    testTriangle1.SetB(Point(6, 10));
    testTriangle1.SetC(Point(11, 15));
    cout << "A: (" << testTriangle1.GetA().GetX() << ", " << testTriangle1.GetA().GetY() << ")" << endl;
    cout << "B: (" << testTriangle1.GetB().GetX() << ", " << testTriangle1.GetB().GetY() << ")" << endl;
    cout << "C: (" << testTriangle1.GetC().GetX() << ", " << testTriangle1.GetC().GetY() << ")" << endl;
    cout << endl;

    cout << "Testing: Triangle class Area Calculation using coordinates from previous test; Triangle class Area getter" << endl;
    testTriangle1.CalculateArea();
    cout << "Area: " << testTriangle1.GetArea() << endl;
    cout << endl;

    cout << "Testing: Triangle class Perimeter Calculation using coordinates from previous test; Triangle class Perimeter getter" << endl;
    testTriangle1.CalculatePerimeter();
    cout << "Perimeter: " << testTriangle1.GetPerimeter() << endl;
    cout << endl;


    cout << "Triangle Game:" << endl;
    cout << "==============================================================================" << endl;

    int base = 0;
    int height = 0;

    cout << endl;
    cout << "Please enter the base length of the triangle: ";
    cin >> base;
    cout << "Please enter the height of the triangle: ";
    cin >> height;

    cout << endl;

    Triangle rightTriangle;

    rightTriangle.CreateRightTriangle(base, height);
    cout << "Generating your triangle: Right triangle with random coordinates (" << rightTriangle.GetA().GetX() << ", " << rightTriangle.GetA().GetY()
        << ") and user inputted base length of " << base << " and height of " << height << endl;
    cout << "A: (" << rightTriangle.GetA().GetX() << ", " << rightTriangle.GetA().GetY() << ")" << endl;
    cout << "B: (" << rightTriangle.GetB().GetX() << ", " << rightTriangle.GetB().GetY() << ")" << endl;
    cout << "C: (" << rightTriangle.GetC().GetX() << ", " << rightTriangle.GetC().GetY() << ")" << endl;
    
    rightTriangle.CalculateArea();
    cout << "Area:" << rightTriangle.GetArea() << endl;
    
    rightTriangle.CalculatePerimeter();
    cout << "Perimeter:" << rightTriangle.GetPerimeter() << endl;
    cout << endl;

    cout << "Let's play a game! Enter the X and Y coordinates of a new point D to see if it exists inside of our generated right triangle." << endl;

    int XofPointD = 0;
    int YofPointD = 0;

    int count = 0;

    while (true) {
        count++;

        cout << endl;
        cout << "Please enter the X coordinate of point D: ";
        cin >> XofPointD;
        cout << "Please enter the Y coordinate of point D: ";
        cin >> YofPointD;

        cout << endl;

        Point D(XofPointD, YofPointD);

        double triangleABD = rightTriangle.CustomCalculateArea(rightTriangle.GetA(), rightTriangle.GetB(), D);
        double triangleBCD = rightTriangle.CustomCalculateArea(rightTriangle.GetB(), rightTriangle.GetC(), D);
        double triangleCAD = rightTriangle.CustomCalculateArea(rightTriangle.GetC(), rightTriangle.GetA(), D);
        double sumOfTriangleAreas = triangleABD + triangleBCD + triangleCAD;

        cout << "Checking if new point D is inside your right triangle..." << endl;
        cout << "Sum of triangles made with new point D = ABD + BCD + CAD = " << triangleABD << " + " << triangleBCD << " + " <<
            triangleCAD << " = " << sumOfTriangleAreas << endl;
        cout << "Result: (Sum of triangle areas) - (right triangle area) = " << sumOfTriangleAreas << " - " << rightTriangle.GetArea() <<
            " = " << (sumOfTriangleAreas - rightTriangle.GetArea()) << endl;

        bool answer = rightTriangle.IsPointInsideTriangle(D);

        cout << endl;

        if (answer) {
            cout << "Your entered point D is in the triangle! You won in only " << count << " tries!" << endl;
            break;
        }
        else {
            cout << "Your entered point D is NOT in the triangle! Keep trying..." << endl;
        }

    }

}

