//Matt Cunningham
//PROG1960 - Assignment #1
//2026-02-18

#ifndef TRIANGLE_H_

#define TRIANGLE_H_
#include <string>
#include "point.h"
using namespace std;

class Triangle {
private:
	Point a, b, c;
	double area;
	double perimeter;
public:
	Triangle();
	Triangle(int, int, int, int, int, int); 
	~Triangle(); 

	Point GetA() const;
	Point GetB() const;
	Point GetC() const;

	void SetA(Point pnt);
	void SetB(Point pnt);
	void SetC(Point pnt);

	void CalculateArea();
	void CalculatePerimeter();

	double GetArea() const;
	double GetPerimeter() const;

	void CreateRightTriangle(double, double);

	double CustomCalculateArea(Point first, Point second, Point third) const;

	bool IsPointInsideTriangle(Point d);
};

#endif 