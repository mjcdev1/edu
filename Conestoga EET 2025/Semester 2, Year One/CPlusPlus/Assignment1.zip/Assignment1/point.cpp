//Matt Cunningham
//PROG1960 - Assignment #1
//2026-02-18

#include <iostream>
#include "point.h"

Point::Point() {
	x = 0;
	y = 0;
}

Point::Point(int z, int j) {
	x = z;
	y = j;
}

int Point::GetX() const {
	return x;
}

int Point::GetY() const {
	return y;
}

void Point::SetX(int z) {
	x = z;
}
void Point::SetY(int z) {
	y = z;
}

Point::~Point() {}
