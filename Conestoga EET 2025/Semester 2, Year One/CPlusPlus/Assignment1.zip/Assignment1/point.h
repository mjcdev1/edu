//Matt Cunningham
//PROG1960 - Assignment #1
//2026-02-18

#ifndef POINT_H_

#define POINT_H_
#include <string>
using namespace std;

class Point {
private:
	int x;
	int y;
public:
	Point();
	Point(int, int);
	~Point();

	int GetX() const;
	int GetY() const;
	void SetX(int);
	void SetY(int);

};
#endif 