//Matt Cunningham
//PROG1960 - Assignment #1
//2026-02-18

#include <iostream>
#include "triangle.h"
#include <random>


Triangle::Triangle() {
	a = Point(0, 0);
	b = Point(0, 0);
	c = Point(0, 0);
	area = 0;
	perimeter = 0;
}

Triangle::Triangle(int x1, int y1, int x2, int y2, int x3, int y3) {
	a = Point(x1, y1);
	b = Point(x2, y2);
	c = Point(x3, y3);
	area = 0;
	perimeter = 0;
}

Point Triangle::GetA() const {
	return a;
}

Point Triangle::GetB() const {
	return b;
}

Point Triangle::GetC() const {
	return c;
}

void Triangle::SetA(Point pnt) {
	a = pnt;
}

void Triangle::SetB(Point pnt) {
	b = pnt;
}

void Triangle::SetC(Point pnt) {
	c = pnt;
}

double Triangle::GetPerimeter() const {
	return perimeter;
}

double Triangle::GetArea() const {
	return area;
}

void Triangle::CalculatePerimeter() {
	int XofA = GetA().GetX();
	int YofA = GetA().GetY();

	int XofB = GetB().GetX();
	int YofB = GetB().GetY();

	int XofC = GetC().GetX();
	int YofC = GetC().GetY();

	double sideAB = sqrt((((XofB - XofA) * (XofB - XofA)) + ((YofB - YofA) * (YofB - YofA))));
	double sideBC = sqrt((((XofC - XofB) * (XofC - XofB)) + ((YofC - YofB) * (YofC - YofB))));
	double sideCA = sqrt((((XofA - XofC) * (XofA - XofC)) + ((YofA - YofC) * (YofA - YofC))));

	perimeter = sideAB + sideBC + sideCA;
}

void Triangle::CalculateArea() {
	double XofA = GetA().GetX();
	double YofA = GetA().GetY();

	double XofB = GetB().GetX();
	double YofB = GetB().GetY();

	double XofC = GetC().GetX();
	double YofC = GetC().GetY();

	area = (XofA * (YofB - YofC) + XofB * (YofC - YofA) + XofC * (YofA - YofB)) / 2;
}

void Triangle::CreateRightTriangle(double base, double height) {
	random_device rd;
	mt19937 gen(rd());
	uniform_int_distribution<> distrib(0, 50);
	int XofARandom = distrib(gen);
	int YofARandom = distrib(gen);

	a = Point(XofARandom, YofARandom);
	b = Point(XofARandom + base, YofARandom);
	c = Point(XofARandom + base, YofARandom + height);
}

double Triangle::CustomCalculateArea(Point first, Point second, Point third) const{
	double XofFirst = first.GetX();
	double YofFirst = first.GetY();

	double XofSecond = second.GetX();
	double YofSecond = second.GetY();

	double XofThird = third.GetX();
	double YofThird = third.GetY();

	double customArea = abs(XofFirst * (YofSecond - YofThird) + XofSecond * (YofThird - YofFirst) + XofThird * (YofFirst - YofSecond)) / 2;
	return customArea;
}

bool Triangle::IsPointInsideTriangle(Point d) {
	double mainTriangleABC = CustomCalculateArea(a, b, c);

	double triangleABD = CustomCalculateArea(a, b, d);
	double triangleBCD = CustomCalculateArea(b, c, d);
	double triangleCAD = CustomCalculateArea(c, a, d);

	double sumOfTriangleAreas = triangleABD + triangleBCD + triangleCAD;

	if (((sumOfTriangleAreas - mainTriangleABC) < 0.01)) {
		return true;
	}
	else {
		return false;
	}
}

Triangle::~Triangle() {}
