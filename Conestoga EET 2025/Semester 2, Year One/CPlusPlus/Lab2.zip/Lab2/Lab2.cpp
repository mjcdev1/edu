/*
Lab 2 - PROG1960
Matt Cunningham
02/04/2026
*/

#include <iostream>
using namespace std;

// Function used from Lab 5 of C course
float GradePoints(const char grade);
float GradePoints(const char grade) {
    switch (grade) {
    case 'A':
        return 4.0;
    case 'B':
        return 3.0;
    case 'C':
        return 2.0;
    case 'D':
        return 1.0;
    case 'F':
        return 0.0;
    default:
        return 0.0;
    }
}

// Function used from Lab 5 of C course
float Gpa(const char grades[], const int hours[], const int arrLength);
float Gpa(const char grades[], const int hours[], const int arrLength) {
    float points = 0;
    float totalHours = 0;
    float result = 0;

    for (int i = 0; i < arrLength; i++) {
        float grade = GradePoints(grades[i]);
        float h = hours[i];
        points += grade * h;
        totalHours += h;
    }

    result = points / totalHours;

    return result;
}

// Function used from Lab 5 of C course, but modified for function overloading
float Gpa(const float gradePoints[], const int hours[], const int arrLength);
float Gpa(const float gradePoints[], const int hours[], const int arrLength) {
    float points = 0;
    float totalHours = 0;
    float result = 0;

    for (int i = 0; i < arrLength; i++) {
        float grade = gradePoints[i];
        float h = hours[i];
        points += grade * h;
        totalHours += h;
    }

    result = points / totalHours;

    return result;
}

int main()
{
    cout << "Welcome to the C++ Student GPA Calculator" << endl << endl;
    cout << "Please enter the number of courses you want to track: ";

    int numCourses = 0;
    cin >> numCourses;
    cout << endl;
    cout << endl;

    char* letterGrade = new char[numCourses];
    int* hours = new int[numCourses];

    float* gradePoints = new float[numCourses];

    for (int i = 0; i < numCourses; i++) {
        cout << "Entering information for course #" << i + 1 << ":" << endl;
        cout << "============================================================" << endl;
        cout << "Enter student's letter grade for this course: ";
        cin >> letterGrade[i];
        cout << "Enter hours for this course: ";
        cin >> hours[i];

        cout << endl;
    }

    for (int i = 0; i < numCourses; i++) {
        gradePoints[i] = GradePoints(letterGrade[i]);
    }

    float gpaByLetterGrade = Gpa(letterGrade, hours, numCourses);
    cout << "(Letter Grade Version) Your GPA is " << gpaByLetterGrade << endl;

    float gpaByGradePoints = Gpa(gradePoints, hours, numCourses);
    cout << "(Grade Point Version) Your GPA is " << gpaByGradePoints << endl;

    delete[] letterGrade;
    delete[] hours;
    delete[] gradePoints;

    return 0;
}
